package br.ueg.webflux.document;

import org.springframework.security.core.GrantedAuthority;

public class Roles implements GrantedAuthority {

	@Override
	public String getAuthority() {
		// TODO Auto-generated method stub
		return null;
	}
}
