package br.ueg.webflux;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProgIvApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProgIvApplication.class, args);
	}

}
